Insert into Customer(ID, Name, Gender, City) values (1, 'Veera','Male','RJY');
Insert into Customer(ID, Name, Gender, City) values (2, 'Hema','Female','HYD');
Insert into Customer(ID, Name, Gender, City) values (3, 'Mani','Male','KKD');
Insert into Customer(ID, Name, Gender, City) values (4, 'Anil','Male','RVP');
Insert into Employee(empid, empname, designation, location) values (1, 'Yesu','SSE','Hyd');
Insert into Employee(empid, empname, designation, location) values (2, 'veera','SE','Hyd');