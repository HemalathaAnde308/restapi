package com.springRESTAPI.demo;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.springRESTAPI.demo.entity.Customer;
import com.springRESTAPI.demo.entity.Employee;
import com.springRESTAPI.demo.exception.EmployeeNotFoundException;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	
	@Autowired
	private CustomerService customerservice;
	
	//Assignment session2 webservicesIntroduction	
		@GetMapping(value="/getUserName/{name}")
		public String getUser(@PathVariable(value="name") String name ) {
		    return "Happy Learning  " +name;
		    
		}
	
	@GetMapping(value="/getAllCustomers")
	public List <Customer> getAllCustomers(){
		List<Customer> customerlist= customerservice.getAllCustomers();
		//System.out.println("customerlist is"+customerlist);
		return customerlist;	
		 
	}
	
	//Hateoas
	// filtering
	// Exception Handling
	@GetMapping(value="/getCustomerById/{id}")
	public EntityModel<Optional<Customer>> getCustomer(@PathVariable(value="id") int ID ){
		Optional<Customer> Customer=customerservice.getCustomerById(ID);
		if(Customer.isPresent()) {
			EntityModel<Optional<Customer>> customer=EntityModel.of(Customer);
			WebMvcLinkBuilder link=linkTo(methodOn(this.getClass()).getAllCustomers());
			customer.add(link.withRel("customers"));
			return customer;		
	}else {
		System.out.println("Not able to throw the exception due to return type of exception and this method return types are different");
		return null;	
	}
	}
	
	@PostMapping(value="/creatercustomer")
	public ResponseEntity<Object> createEmployee(@Valid @RequestBody Customer customer) {
		Customer customeradded=customerservice.createCustomer(customer);
		return new ResponseEntity<>(customeradded,HttpStatus.OK);
		
	}
	
	@DeleteMapping(value="/deletecustomer/{id}")
	public void updateCustomer(@PathVariable(value="id") int ID) {
		customerservice.deleteCustomer(ID);
	
	}
}




