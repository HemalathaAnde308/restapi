package com.springRESTAPI.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springRESTAPI.demo.entity.Employee;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeDAO employeedao;
	
	public List<Employee> getEmployeeDetails(){
		return employeedao.findAll();
		
	}
	
	public Employee createEmployee(Employee employee){
	     return employeedao.save(employee);
		
	}

}
