package com.springRESTAPI.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name="Employee")
public class Employee {
	
	
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public Employee(long empid, String empname, String designation, String location) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.designation = designation;
		this.location = location;
	}


	@Id
	@Column
	private long empid;
	
	@Column
	private String empname;
	
	@Column
	private String designation;
	
	@Column
	@JsonIgnore
	private String location;

	public long getEmpid() {
		return empid;
	}

	public void setEmpid(long empid) {
		this.empid = empid;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
	

}
