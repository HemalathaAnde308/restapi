package com.springRESTAPI.demo.exception;

public class CustomerNotFoundException extends RuntimeException {

}
