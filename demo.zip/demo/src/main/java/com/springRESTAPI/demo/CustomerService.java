package com.springRESTAPI.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springRESTAPI.demo.entity.Customer;
import com.springRESTAPI.demo.entity.Employee;
import com.springRESTAPI.demo.exception.CustomerNotFoundException;

@Service
public class CustomerService {

	@Autowired
    private RepositoryDAO CustomerDAO;
	public List<Customer> getAllCustomers(){
	return CustomerDAO.findAll();
	}
	
	public   Optional<Customer> getCustomerById(int a) {
	try {
		 return CustomerDAO.findById(a);
	} catch(Exception e) {
		throw new CustomerNotFoundException();
	}
	}

	public void deleteCustomer(int iD) {
		// TODO Auto-generated method stub
		 CustomerDAO.deleteById(iD);
	}

	public Customer createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return CustomerDAO.save(customer);
		
	}
	
}
