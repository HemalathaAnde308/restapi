package com.springRESTAPI.demo.exception;

@SuppressWarnings("serial")
public class EmployeeNotFoundException extends RuntimeException {

	
}
