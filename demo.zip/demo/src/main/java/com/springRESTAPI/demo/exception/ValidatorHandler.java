package com.springRESTAPI.demo.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class ValidatorHandler extends ResponseEntityExceptionHandler {

}
